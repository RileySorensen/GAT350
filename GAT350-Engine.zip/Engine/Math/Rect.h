#pragma once

namespace neu
{
	struct Rect
	{
		int x;
		int y;
		int w;
		int h;
	};
}